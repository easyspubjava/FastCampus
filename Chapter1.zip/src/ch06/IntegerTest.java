package ch06;

public class IntegerTest {

	public static void main(String[] args) {
		byte bs = 127;
		
		System.out.println(bs);
		
		//int  iVal = 12345678900;
		long lVal = 12345678900L; 

	}

}
